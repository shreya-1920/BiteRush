const Restaurant = require("../models/Restaurant");

// Get All Restaurants
exports.getRestaurants = async (req, res) => {
  try {
    const restaurants = await Restaurant.find();

    res.status(200).json({
      success: true,
      restaurants,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get Restaurant By ID
exports.getRestaurant = async (req, res) => {
  try {

    const restaurant = await Restaurant.findById(req.params.id);

    if (!restaurant) {
      return res.status(404).json({
        success: false,
        message: "Restaurant not found",
      });
    }

    res.status(200).json({
      success: true,
      restaurant,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Add Restaurant
exports.createRestaurant = async (req, res) => {
  try {
    const restaurant = await Restaurant.create(req.body);

    res.status(201).json({
      success: true,
      restaurant,
    });

  } catch (error) {
    console.log(error);

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Update Restaurant
exports.updateRestaurant = async (req, res) => {

  try {

    const restaurant = await Restaurant.findByIdAndUpdate(

      req.params.id,

      req.body,

      {
        new: true,
        runValidators: true,
      }

    );

    if (!restaurant) {

      return res.status(404).json({
        success: false,
        message: "Restaurant not found",
      });

    }

    res.status(200).json({
      success: true,
      restaurant,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }

};

// Delete Restaurant
exports.deleteRestaurant = async (req, res) => {

  try {

    const restaurant = await Restaurant.findByIdAndDelete(req.params.id);

    if (!restaurant) {

      return res.status(404).json({
        success: false,
        message: "Restaurant not found",
      });

    }

    res.status(200).json({
      success: true,
      message: "Restaurant deleted successfully",
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }

};